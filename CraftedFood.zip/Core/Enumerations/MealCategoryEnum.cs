﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Enumerations
{
    public enum MealCategoryEnum
    {
       Salad = 1,
       Sandwich,
       Bakery,
       Pasta,
       Sweet,
       Drink,
       CookedMeal
    }
}
