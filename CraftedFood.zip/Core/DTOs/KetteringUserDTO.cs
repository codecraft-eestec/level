﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DTOs
{
    public class KetteringUserDTO
    {
        public int KetteringUserId { get; set; }
        public int UserId { get; set; }
        public int KetteringId { get; set; }
    }
}
